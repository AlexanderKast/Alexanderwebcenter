---
name: skill-research
description: 'Disciplina de investigación — buscar y verificar antes de afirmar, y solo después construir el entregable. Usa esta skill SIEMPRE que la tarea involucre datos del mundo real (precios, competidores, tendencias, herramientas, personas, leyes, estadísticas), que el usuario pida "investiga", "busca", "analiza el mercado", o que un documento/reporte/decisión dependa de hechos que podrían haber cambiado. Aplica aunque creas saber la respuesta de memoria: la memoria de un modelo siempre está desactualizada.'
---

# Investigación Primero (`skill-research`)

La diferencia entre un reporte útil y uno peligroso es que el segundo suena igual de seguro pero está inventado. Esta skill establece el orden correcto: **hechos primero, formato después** — y ninguna afirmación del mundo presente sin fuente.

## Regla 1 — La memoria no es fuente

Para cualquier dato del mundo actual (precios, quién dirige qué, qué herramienta es mejor, estadísticas, regulaciones, qué hace un competidor), busca antes de afirmar. La confianza que sientas en el dato no es motivo para saltarte la búsqueda: los precios cambian, las empresas pivotan, las leyes se actualizan. Si no puedes buscar, marca el dato explícitamente: "según mi conocimiento, que puede estar desactualizado...".

## Regla 2 — Primero investigar, después formatear

Nunca abras el documento/presentación/hoja de cálculo antes de tener el contenido verificado. Empezar por el formato ancla el trabajo en la estructura y termina rellenándose con generalidades. El flujo correcto:

1. Define las preguntas que la investigación debe responder.
2. Busca y recolecta (ver Regla 3).
3. Sintetiza y verifica.
4. Solo entonces, construye el entregable.

## Regla 3 — Cómo buscar bien

- **Varias búsquedas cortas superan a una larga.** Descompón el tema en preguntas específicas y busca cada una.
- **Triangula lo importante.** Cualquier dato que afecte una decisión (un precio, una estadística clave, una afirmación fuerte) necesita al menos 2 fuentes independientes. Si las fuentes se contradicen, repórtalo — no elijas en silencio la que más conviene.
- **Evalúa la fuente.** ¿Quién lo dice y qué gana diciéndolo? El blog del vendedor no es fuente neutral sobre su producto. Prefiere fuentes primarias (el sitio oficial, el estudio original, el documento legal) sobre resúmenes de terceros.
- **Fecha los datos.** Un dato sin fecha es medio dato. "El CPM promedio es $X (dato de 2023)" permite al lector calibrar; "el CPM promedio es $X" a secas puede engañar.
- **Registra las fuentes mientras avanzas**, no al final. Reconstruir de dónde salió cada dato después es lento y propenso a errores.

## Regla 4 — Sintetiza, no acumules

Un volcado de 20 hallazgos sin digerir no es investigación, es una bandeja de entrada. Al sintetizar:

- Responde directamente las preguntas definidas al inicio.
- Separa con claridad tres niveles: **hecho verificado** (con fuente), **estimación razonada** (y su lógica), y **opinión/interpretación**. Mezclarlos es la forma más común de desinformar sin mentir.
- Señala lo que NO se pudo averiguar. Los vacíos honestos valen más que rellenos elegantes.

## Regla 5 — Cierra con fuentes

Todo entregable basado en investigación termina con una sección de fuentes enlazadas. Formato: `[Título o medio](URL)` — suficiente para que el usuario verifique cualquier afirmación en un clic.

## Ejemplo del flujo

Petición: "Analiza si me conviene vender el producto X en Ecuador."

1. Preguntas: ¿demanda/búsquedas de X en Ecuador? ¿competidores activos y sus precios? ¿costos de importación/envío? ¿restricciones legales? ¿márgenes resultantes?
2. Búsquedas separadas por pregunta; triangular precios de competidores con al menos 2 tiendas reales.
3. Síntesis: tabla de márgenes con datos fechados, riesgos identificados, y lo que no se pudo verificar (ej. volumen real de ventas de competidores — solo estimable).
4. Recién ahí: el reporte/documento final, con fuentes al pie.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
