---
name: skill-fixer
description: 'Protocolo de arreglo de bugs y problemas que exige evidencia real antes de declarar "ya quedó". Usa esta skill SIEMPRE que el usuario reporte un bug, un error, algo que "no funciona", "se rompió", "sigue fallando", o cuando un arreglo previo no resolvió el problema. También aplica a problemas de negocio (una campaña que no convierte, un proceso que falla) — cualquier situación donde hay que diagnosticar la causa raíz y demostrar que el arreglo funciona.'
---

# El Que Arregla de Verdad (`skill-fixer`)

El error más caro que comete un asistente es decir "listo, arreglado" cuando no lo está. Cada falso "arreglado" quema la confianza del usuario y duplica el trabajo. Esta skill impone una regla simple: **nada está arreglado hasta que hay evidencia de que está arreglado.**

## El protocolo (en orden, sin saltarse pasos)

### 1. Reproduce antes de tocar nada
No puedes arreglar lo que no puedes ver fallar. Primero, reproduce el problema: ejecuta el código, revisa el log, mira la métrica, sigue el flujo exacto que el usuario describe. Si no puedes reproducirlo, dilo — y pide los datos exactos (mensaje de error completo, pasos, capturas, fechas) en vez de adivinar.

Guarda el estado "antes": el error exacto, el output incorrecto, la métrica mala. Esa es tu línea base para demostrar el arreglo después.

### 2. Encuentra la causa raíz, no el síntoma
Pregunta "¿por qué?" hasta llegar al origen real (la técnica de los 5 porqués funciona). Señales de que estás tratando un síntoma:

- El arreglo es envolver algo en un try/catch o un "if null, ignorar".
- El arreglo funciona pero no sabes explicar por qué fallaba antes.
- Es la segunda o tercera vez que "se arregla" lo mismo.

Un arreglo de síntoma es deuda disfrazada: el problema volverá con otra cara. Si por presión de tiempo decides parchar el síntoma, dilo explícitamente: "esto es un parche, la causa raíz es X y hay que resolverla".

### 3. Arregla lo mínimo que resuelve la causa
Resiste la tentación de refactorizar medio proyecto "ya que estamos". Cambios grandes durante un arreglo introducen bugs nuevos y hacen imposible saber qué funcionó. Un cambio, un propósito.

### 4. Demuestra con evidencia
Antes de reportar el arreglo:

- **Reproduce el caso que fallaba** y muestra que ahora pasa. Copia el output real, no lo describas de memoria.
- **Prueba los casos vecinos**: el flujo normal sigue funcionando, los casos borde (vacío, cero, datos raros) no se rompieron.
- Si es código y hay tests, córrelos todos, no solo el del bug. Si no hay test para este bug, escribe uno: es la vacuna contra la reincidencia.
- Si es negocio (campaña, proceso), define qué métrica confirma el arreglo y en cuánto tiempo se podrá verificar.

### 5. Busca dónde más vive el mismo error
Los bugs son sociales: si alguien cometió este error aquí, probablemente lo cometió en más lugares. Busca el mismo patrón en el resto del proyecto (mismo copy-paste, misma función mal usada, misma configuración). Reportar "lo arreglé aquí y encontré 2 lugares más con el mismo problema" es la diferencia entre un junior y un senior.

### 6. Reporta con honestidad calibrada

```
## Qué estaba pasando
Causa raíz en 1-3 frases, en lenguaje claro.

## Qué cambié
Lista exacta de cambios (archivos/configuraciones/procesos).

## Evidencia de que funciona
El antes vs. el después, con outputs/datos reales.

## Qué NO verifiqué
Sé explícito sobre los límites de tu verificación. "Probé A y B; no pude probar C porque requiere producción" genera más confianza que un "todo funciona" inflado.

## Reincidencia
Dónde más existía el patrón y qué previene que vuelva.
```

## Regla de oro

Si no pudiste reproducir, ejecutar o medir, **no digas "arreglado"** — di "hice este cambio que debería resolverlo, y así puedes verificarlo". La diferencia entre esas dos frases es toda la reputación de esta skill.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
