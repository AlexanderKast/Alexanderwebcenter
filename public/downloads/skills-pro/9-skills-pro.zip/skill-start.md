---
name: skill-start
description: 'Protocolo para arrancar proyectos nuevos con bases sólidas, evitando que se caigan al mes. Usa esta skill SIEMPRE que el usuario diga "quiero empezar un proyecto", "vamos a crear una app/tienda/negocio/agencia/curso", "arranquemos con...", o pida ayuda para iniciar cualquier cosa desde cero — código, ecommerce, contenido, servicio o automatización. También aplica cuando pida "estructura inicial", "MVP" o "por dónde empiezo".'
---

# El Arranque (`skill-start`)

La mayoría de proyectos no mueren por falta de ideas: mueren porque se construyeron sobre decisiones que nadie tomó conscientemente. Esta skill existe para tomar esas decisiones al inicio, cuando cambiar de rumbo cuesta minutos y no meses.

## Fase 1 — Entender antes de construir

Antes de crear un solo archivo o cuenta, responde (preguntando al usuario lo que no sepas, máximo 4 preguntas a la vez):

1. **¿Qué problema resuelve y para quién?** Una frase. Si no cabe en una frase, el proyecto aún no está claro.
2. **¿Cómo se ve el éxito en 90 días?** Algo medible: ventas, usuarios, entregas, no "que funcione".
3. **¿Qué es lo mínimo que prueba la idea?** Separa el corazón del proyecto de todo lo que es decoración. El 80% de las funciones "necesarias" no lo son para la versión 1.
4. **¿Qué recursos reales hay?** Tiempo semanal, presupuesto, habilidades del equipo. Un plan que ignora esto es ficción.
5. **¿Qué lo mataría?** El riesgo #1 (técnico, de mercado, legal, de tiempo). El arranque debe atacar ese riesgo primero, no dejarlo para el final.

## Fase 2 — Decisiones de fundación

Documenta explícitamente estas decisiones. "Lo decidimos después" es también una decisión, casi siempre mala:

- **Alcance de la v1**: lista corta de lo que SÍ entra y — más importante — lista de lo que NO entra. Escribir el "no" evita el crecimiento silencioso del alcance.
- **Stack / plataforma**: elige lo aburrido y probado sobre lo novedoso, salvo que la novedad sea el negocio. Para código: el lenguaje/framework que el equipo ya domina. Para negocio: la plataforma con menor fricción (no montes infraestructura propia si Shopify/Stripe/etc. resuelven).
- **Estructura**: carpetas, nombres, dónde vive cada cosa. En código: repo con README, .gitignore y .env.example desde el commit 1. En negocio: dónde viven los documentos, quién es dueño de cada cuenta.
- **Criterio de "terminado"** para la v1: la condición concreta que dispara el lanzamiento. Sin esto, los proyectos entran en pulido infinito.

## Fase 3 — Esqueleto que funciona el día 1

Construye primero la versión más delgada que atraviesa todo el flujo de punta a punta, aunque sea fea:

- En software: un "hola mundo" desplegado y accesible antes de escribir funcionalidades. Desplegar al final es donde mueren los proyectos.
- En ecommerce: una página de producto que puede recibir un pedido real antes de tener 50 productos cargados.
- En contenido/servicios: una entrega real a un cliente/seguidor antes de perfeccionar el sistema.

El esqueleto de punta a punta revela los problemas de integración cuando aún son baratos.

## Fase 4 — Ritmo y protección contra el abandono

- Define el ciclo de trabajo: qué se revisa cada semana y qué señal indicaría pivotar o parar.
- Deja escrito un `DECISIONES.md` (o documento equivalente): cada decisión importante con fecha y por qué. Tu yo de dentro de 3 meses no recordará nada.
- Programa el primer checkpoint de verdad: fecha concreta en la que se evalúa contra la métrica de éxito de la Fase 1.

## Entregable

Al terminar el arranque, entrega un documento breve con: resumen del proyecto (1 frase), métrica de éxito a 90 días, alcance v1 (sí/no), decisiones de fundación, riesgo #1 y cómo se ataca, y el plan de las primeras 2 semanas con tareas concretas.

## Señales de alerta que debes frenar

- El usuario quiere empezar por el logo, el nombre o el diseño antes de validar el problema. Redirige con amabilidad: eso es Fase 4, no Fase 1.
- El alcance de la v1 tiene más de ~7 elementos. Recorta con el usuario.
- Nadie puede decir cómo se medirá el éxito. No avances hasta tenerlo.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
