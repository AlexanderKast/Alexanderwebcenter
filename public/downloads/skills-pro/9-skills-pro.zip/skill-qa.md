---
name: skill-qa
description: 'Verificación final de entregables antes de entregarlos — el paso de control de calidad que los modelos se saltan. Usa esta skill SIEMPRE que estés por entregar cualquier trabajo terminado: un documento, código, hoja de cálculo, plan, diseño, guion o análisis. Aplica automáticamente al final de toda tarea no trivial, sin que el usuario lo pida: revisar antes de entregar es parte del trabajo, no un extra.'
---

# Control de Calidad (`skill-qa`)

El último 5% del trabajo (revisarlo) produce el 50% de la percepción de calidad. Un análisis brillante con una cifra mal sumada pierde toda credibilidad. Esta skill convierte la revisión en un paso obligatorio, con la mentalidad correcta: **revisa como si el trabajo lo hubiera hecho otra persona en quien no confías del todo.**

## El cambio de sombrero

Al terminar de producir, cambia de rol: ya no eres el autor defendiendo su obra, eres el revisor buscando por qué podría estar mal. El autor lee lo que quiso escribir; el revisor lee lo que realmente está escrito. Haz una pasada completa con ojos nuevos antes de entregar.

## Checklist según el tipo de entregable

### Todo entregable
- ¿Responde a lo que el usuario realmente pidió, en el formato que pidió? Relee la petición original — es sorprendente cuántas veces el entregable deriva hacia otra cosa.
- ¿Los nombres, fechas y datos específicos del usuario están correctos (no inventados ni confundidos con otros)?
- ¿Hay promesas del texto que el contenido no cumple? (Un título que dice "5 estrategias" con 4 estrategias.)

### Números y datos
- **Verifica todo cálculo programáticamente o a mano, nunca "de vista".** Suma las columnas, recalcula los porcentajes, verifica que las partes sumen el total.
- ¿Las cifras son consistentes entre secciones? (El resumen dice $3.000 y la tabla dice $3.500 — clásico.)
- ¿Cada dato del mundo real tiene fuente, y las fuentes citadas dicen lo que se les atribuye?

### Código
- **Ejecútalo.** Código no ejecutado es código no verificado, por obvio que parezca. Corre el flujo principal y al menos un caso borde.
- ¿Los tests pasan — todos, no solo los nuevos?
- ¿Quedaron restos: prints de debug, TODOs, credenciales de prueba, código muerto?

### Documentos y contenido
- Ortografía y gramática (en el idioma del usuario).
- ¿La estructura fluye o hay secciones que se repiten/contradicen?
- ¿El tono corresponde a la audiencia declarada?
- Enlaces: ¿funcionan y apuntan a donde dicen?

### Hojas de cálculo
- Abre el archivo generado y verifica que se ve como debería (fórmulas calculan, no hay #REF!, los formatos aplican).
- Verifica 2-3 celdas calculadas contra un cálculo manual.

## Cómo reportar la verificación

Al entregar, incluye un mini-reporte de QA de 2-4 líneas: qué verificaste y cómo, y qué no pudiste verificar. Ejemplo:

> Verifiqué: los totales de la hoja recalculados con script (coinciden), los 6 enlaces (funcionan), y ortografía. No pude verificar: los precios del proveedor, que tomé del documento que me pasaste.

Esto no es burocracia: es lo que le permite al usuario confiar en el trabajo sin re-revisarlo todo.

## Si encuentras errores propios

Arréglalos y menciónalo con naturalidad ("en la revisión encontré un error de suma en la tabla 2, ya corregido"). Encontrar y corregir tus propios errores antes de entregar es señal de calidad, no de debilidad. Lo que destruye confianza es que los encuentre el usuario.

## Para trabajo de alto riesgo

Si el entregable afecta dinero, clientes o decisiones importantes, sube el nivel: verifica con un método independiente del que usaste para producir (otro cálculo, otra fuente, otro camino de código). Si hay subagentes disponibles, delega la revisión a uno que no haya visto el proceso de producción — la revisión independiente encuentra lo que el autor no puede ver.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
