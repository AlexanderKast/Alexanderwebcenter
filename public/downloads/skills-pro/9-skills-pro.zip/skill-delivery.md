---
name: skill-delivery
description: 'Estándar de entrega profesional — archivos reales, comunicación limpia y reportes cortos. Usa esta skill SIEMPRE que se produzca un entregable para el usuario: documentos, reportes, código, hojas de cálculo, presentaciones, guiones o planes. Aplica al momento de decidir CÓMO entregar el trabajo (archivo vs. texto en chat, cuánto explicar, qué formato), en cualquier tarea de creación de contenido o trabajo terminado.'
---

# Entrega Profesional (`skill-delivery`)

El trabajo no termina cuando está hecho: termina cuando el usuario lo recibe en la forma en que puede usarlo. Un análisis excelente pegado como un muro de texto en el chat es trabajo a medio entregar. Esta skill define el estándar.

## Regla 1 — Archivo real, no texto pegado

Si el contenido va a usarse fuera de la conversación (enviarse, editarse, presentarse, guardarse), créalo como archivo en el formato correcto:

- Informe/documento profesional → .docx (o .md si es para uso técnico)
- Datos, tablas, cálculos → .xlsx con fórmulas reales, no números pegados
- Presentación → .pptx
- Código → archivos de código, no bloques en el chat (más de ~10 líneas de código = archivo)
- Guiones y piezas de contenido → documento editable

La prueba: ¿el usuario querría copiar/pegar esto a otro lugar? Si sí, debió ser un archivo desde el principio. En cambio, respuestas conversacionales, explicaciones y listas rápidas viven bien en el chat — no crees archivos por deporte.

## Regla 2 — El formato correcto es el mínimo necesario

- Prosa clara en párrafos cortos por defecto. Listas y tablas solo cuando la información es genuinamente enumerable o comparativa.
- Nada de negrilla en cada frase, ni tres niveles de encabezados para un texto de una página, ni emojis decorativos en documentos profesionales.
- Escribe en el idioma del usuario y en el tono de su audiencia (un guion para Instagram no suena como un contrato).
- Los títulos prometen; el contenido debe cumplir exactamente lo prometido.

## Regla 3 — Reporta corto; el trabajo habla solo

Al entregar, resiste el impulso de narrar todo lo que hiciste. El reporte de entrega ideal tiene tres partes y cabe en pocas líneas:

1. **Qué se entrega** (1 frase) y dónde está.
2. **Las 1-3 decisiones que tomaste** que el usuario debería conocer o podría querer cambiar ("usé el precio de la lista de marzo porque...", "dejé fuera X porque...").
3. **Qué sigue**, si aplica (1 frase).

El usuario puede abrir el documento; no necesita que se lo resumas entero en el chat. Explicar de más diluye lo importante y le roba tiempo.

## Regla 4 — Entrega verificada o entrega calificada

Antes de entregar, el trabajo pasó su verificación (si existe una skill de QA, ya se aplicó). Si algo NO se pudo verificar, la entrega lo dice explícitamente en una línea. Nunca entregues con confianza uniforme algo que tiene partes sólidas y partes dudosas — califica cada cosa como lo que es.

## Regla 5 — Piensa en el siguiente paso del usuario

La entrega profesional se anticipa: si entregas un análisis, ¿el siguiente paso natural es una decisión? Ofrece los 2-3 caminos. ¿Entregas código? Indica cómo ejecutarlo en una línea. ¿Entregas un guion? Menciona qué falta para grabarlo. Una frase de anticipación convierte un entregable en un avance del proyecto.

## Ejemplo de cierre de entrega

> Listo el análisis de márgenes en `margenes-productos.xlsx` (hoja 2 tiene el comparativo). Dos decisiones: excluí el producto C por falta de datos de costo, y calculé envíos con la tarifa de Servientrega. Si me confirmas el costo de C, lo integro en 5 minutos.

Tres líneas. Todo lo que el usuario necesita, nada que no.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
