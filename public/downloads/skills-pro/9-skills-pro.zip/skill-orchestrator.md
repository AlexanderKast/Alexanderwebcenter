---
name: skill-orchestrator
description: 'Cómo fragmentar tareas grandes en subtareas, delegarlas (en paralelo cuando se pueda) y consolidar resultados coherentes. Usa esta skill SIEMPRE que la tarea sea grande o multifacética: investigar varios temas, procesar muchos archivos, construir algo con varias partes independientes, comparar múltiples opciones, o cualquier trabajo que tomaría muchos pasos secuenciales. También cuando el usuario pida "analiza todo esto", "revisa estos 10 productos" o entregue proyectos completos.'
---

# El Orquestador (`skill-orchestrator`)

Las tareas grandes no fallan por difíciles: fallan por indigestas. Un modelo que intenta hacerlo todo en una sola pasada pierde el hilo, mezcla contextos y entrega un resultado desigual. El orquestador piensa como un gerente: divide, delega, y se reserva para lo que solo él puede hacer — decidir y consolidar.

## Paso 1 — Decide si vale la pena fragmentar

Fragmenta cuando: hay varias unidades de trabajo similares (10 productos que analizar, 5 competidores que investigar), hay partes independientes entre sí, o el contexto necesario para hacerlo todo junto es demasiado grande.

NO fragmentes cuando: la tarea es corta, las partes dependen fuertemente unas de otras, o el costo de coordinar supera el de simplemente hacerlo. Fragmentar una tarea de 10 minutos en 5 subtareas es teatro de productividad.

## Paso 2 — Diseña las subtareas como encargos completos

Cada subtarea debe poder ejecutarse **sin acceso a esta conversación**. El error clásico es delegar con contexto implícito ("analiza el competidor" — ¿cuál? ¿bajo qué criterios?). Cada encargo incluye:

- **Objetivo**: qué debe producir, en una frase.
- **Contexto mínimo suficiente**: los datos que necesita (no todo el proyecto, solo lo relevante).
- **Formato de salida exacto**: campos, estructura, idioma. Si las subtareas son paralelas y sus salidas se van a consolidar, el formato uniforme es lo que hace posible la consolidación. Defínelo antes de lanzar la primera.
- **Límites**: qué NO debe hacer, cuándo parar, qué hacer si se atasca.

## Paso 3 — Ejecuta en paralelo lo independiente

- Identifica qué subtareas no dependen entre sí y lánzalas a la vez (si hay subagentes disponibles, en el mismo turno; si no, ejecútalas en secuencia pero sin re-decidir el enfoque cada vez — el diseño ya está hecho).
- Ordena las dependientes por riesgo: primero la que puede invalidar a las demás. Si la subtarea 1 revela que el enfoque está mal, mejor saberlo antes de haber corrido las otras 9.
- Para lotes grandes (20+ unidades), corre primero un **piloto de 2-3 unidades**, revisa la calidad del formato y ajusta el encargo antes de lanzar el resto. Corregir el encargo cuesta minutos; corregir 20 resultados malos cuesta horas.

## Paso 4 — Consolida con criterio, no con grapadora

Pegar las salidas una tras otra no es consolidar. Al integrar:

- **Verifica consistencia**: ¿las subtareas usaron los mismos criterios? ¿Hay contradicciones entre resultados? Las contradicciones se resuelven o se reportan, nunca se ocultan.
- **Extrae las conclusiones transversales**: los patrones que solo se ven mirando todos los resultados juntos son el valor que justifica la orquestación.
- **Normaliza el tono y formato** para que el entregable final parezca escrito por una sola mente.
- Aplica control de calidad sobre el conjunto: revisa al menos por muestreo que las subtareas hicieron lo encargado (una subtarea que malinterpretó el encargo contamina el total).

## Paso 5 — Reporta la estructura, no el drama

Al entregar, el usuario no necesita la crónica de la orquestación; necesita el resultado y un mapa breve: cómo se dividió el trabajo, qué se verificó, y dónde están los detalles de cada parte por si quiere profundizar.

## Ejemplo

"Analiza mis 5 competidores y dime cómo diferenciarme."

1. Fragmentar: 5 subtareas idénticas (una por competidor) + 1 de síntesis.
2. Encargo uniforme: para cada competidor → oferta, precios, ángulo de marketing, debilidades visibles, fuentes. Mismo formato de salida los 5.
3. Correr las 5 en paralelo.
4. Consolidar: tabla comparativa + patrones del mercado + los 2-3 huecos que nadie está cubriendo (la conclusión transversal).
5. Entregar el análisis con el mapa de cómo se construyó.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
