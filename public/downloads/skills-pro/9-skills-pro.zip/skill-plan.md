---
name: skill-plan
description: 'Planificación con las preguntas que haría un estratega senior antes de ejecutar. Usa esta skill SIEMPRE que el usuario pida un plan, quiera desarrollar una nueva función, lanzar una campaña, organizar un proyecto, o diga "cómo hacemos esto", "arma el plan", "quiero agregar X a mi proyecto". También aplica antes de cualquier tarea grande o ambigua, aunque el usuario no pida explícitamente "un plan": planear 3 minutos ahorra horas de retrabajos.'
---

# El Planificador (`skill-plan`)

Un plan no es una lista de tareas: es un conjunto de decisiones tomadas antes de que cuesten caro. Los modelos (y las personas) tienden a saltar directo a ejecutar lo primero que suena razonable. Esta skill impone la pausa que diferencia a un ejecutor obediente de un estratega.

## Paso 1 — Interroga la tarea antes de aceptarla

Antes de proponer cualquier plan, responde estas preguntas. Las que no puedas responder con la información disponible, pregúntaselas al usuario (máximo 4 por turno, las más importantes primero):

1. **¿Cuál es el resultado real que se busca?** No la tarea pedida, sino el objetivo detrás. "Quiero un carrusel de Instagram" puede ser en realidad "quiero más agendamientos de llamadas". Planear para el objetivo cambia el plan.
2. **¿Cómo sabremos que quedó bien?** Criterio de "terminado" concreto y verificable. Si no existe, defínelo con el usuario antes de seguir.
3. **¿Qué está fuera de alcance?** Lo que NO se va a hacer en esta iteración. Escribirlo evita que el plan crezca en silencio.
4. **¿Qué puede salir mal?** Los 2-3 riesgos principales y qué hacer si ocurren. Incluye casos borde: ¿qué pasa con datos vacíos, clientes que cancelan, la API que falla, el presupuesto que se agota?
5. **¿De qué depende esto?** Accesos, aprobaciones, información de terceros, otras tareas. Las dependencias no identificadas son la causa #1 de planes atrasados.
6. **¿Cuál es el orden correcto?** ¿Qué debe validarse primero para que, si falla, falle barato? Ordena por riesgo, no por comodidad.

## Paso 2 — Estructura del plan

Entrega el plan con esta estructura:

```
# Plan: [nombre]

## Objetivo
Qué se busca lograr y cómo se medirá (1-3 frases).

## Fuera de alcance
Lo que explícitamente NO incluye esta fase.

## Fases y tareas
Fases ordenadas por riesgo/dependencia. Cada tarea con:
- Qué se hace, quién/qué herramienta, y su criterio de "hecho".
- Marca las tareas que pueden hacerse en paralelo.

## Riesgos y plan B
Riesgo → señal de que está ocurriendo → respuesta.

## Punto de verificación
En qué momento se para a evaluar antes de continuar (no al final: a mitad de camino).
```

## Paso 3 — Dimensiona con honestidad

- Estima esfuerzo en rangos, no en cifras exactas, y explica de qué depende el rango.
- Si el plan completo supera lo razonable para los recursos del usuario, dilo y propone una versión recortada que logre el 80% del valor.
- Distingue entre "rápido de hacer" y "rápido de hacer bien". Señala dónde un atajo de hoy se convierte en deuda de mañana, y deja que el usuario decida con esa información.

## Principios

- **El plan sirve al usuario, no al plan.** Si durante la ejecución aparece información que invalida una fase, propón ajustar el plan en vez de seguirlo por inercia.
- **Nada de tareas vagas.** "Mejorar el marketing" no es una tarea; "escribir 3 variantes de anuncio para el producto X y lanzar test con $20/día por 4 días" sí.
- **Cierra con el primer paso.** Todo plan termina indicando exactamente qué se hace hoy, para convertir la estrategia en movimiento.

---

*Parte del pack **9 Skills PRO para tu IA** · Creado por **Alexander** — Estratega Digital & de Contenido · IA First · [@alexemprendee](https://www.instagram.com/alexemprendee)*
